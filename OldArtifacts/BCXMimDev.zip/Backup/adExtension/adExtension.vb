
Imports Microsoft.MetadirectoryServices

Public Class MAExtensionObject
    Implements IMASynchronization

    Public Sub Initialize() Implements IMASynchronization.Initialize
        ' TODO: Add initialization code here
    End Sub

    Public Sub Terminate() Implements IMASynchronization.Terminate
        ' TODO: Add termination code here
    End Sub

    Public Function ShouldProjectToMV(ByVal csentry As CSEntry, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ShouldProjectToMV
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function

    Public Function FilterForDisconnection(ByVal csentry As CSEntry) As Boolean Implements IMASynchronization.FilterForDisconnection
        ' TODO: Add connector filter code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForJoin(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByRef values As ValueCollection) Implements IMASynchronization.MapAttributesForJoin
        ' TODO: Add join mapping code here
        Throw New EntryPointNotImplementedException()
    End Sub

    Public Function ResolveJoinSearch(ByVal joinCriteriaName As String, ByVal csentry As CSEntry, ByVal rgmventry() As MVEntry, ByRef imventry As Integer, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ResolveJoinSearch
        ' TODO: Add join resolution code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForImport(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByVal mventry As MVEntry) Implements IMASynchronization.MapAttributesForImport

        Select Case FlowRuleName


            Case "cd.user:employeeNumber->mv.person:employeeNr"
                If csentry("employeeNumber").IsPresent Then
                    Try
                        Dim tempEmpNr As Integer = Convert.ToInt32(csentry("employeeNumber").Value)
                        mventry("employeeNr").Value = tempEmpNr
                    Catch
                        'Add some Error handling. 
                        'Throw
                    End Try

                End If



            Case Else
                ' TODO: remove the following statement and add your default script here
                Throw New EntryPointNotImplementedException()



        End Select
    End Sub

    Public Sub MapAttributesForExport(ByVal FlowRuleName As String, ByVal mventry As MVEntry, ByVal csentry As CSEntry) Implements IMASynchronization.MapAttributesForExport


         Select FlowRuleName

            'Set the AD account to Enable or Disabled accourding to HR
            Case "cd.user:userAccountControl<-mv.person:employeeStatus,accountName"


                'Get the employeeStatus for the record. Need to check the Staff and Contractor status.
                Dim employeeStatus As String = Nothing
                If mventry("employeeStatus").IsPresent Then
                    employeeStatus = mventry("employeeStatus").Value

                    '  If mventry("employeeStatusStaffRecord").IsPresent And mventry("employeeStatusContractorRecord").IsPresent Then
                    'If (mventry("employeeStatusStaffRecord").Value = "Terminated") And (mventry("employeeStatusContractorRecord").Value = "Terminated") Then
                    'employeeStatus = "Terminated"
                    'Else
                    'employeeStatus = "Active"
                    'End If
                    'ElseIf (mventry("employeeStatusStaffRecord").IsPresent = False) And (mventry("employeeStatusContractorRecord").IsPresent) Then
                    'If mventry("employeeStatusContractorRecord").Value = "Terminated" Then
                    ' employeeStatus = "Terminated"
                    'Else
                    'employeeStatus = "Active"
                    'End If
                    'ElseIf (mventry("employeeStatusStaffRecord").IsPresent) And (mventry("employeeStatusContractorRecord").IsPresent = False) Then
                    'If mventry("employeeStatusStaffRecord").Value = "Terminated" Then
                    ' employeeStatus = "Terminated"
                    'Else
                    'employeeStatus = "Active"
                    'End If
                    'ElseIf (mventry("employeeStatusStaffRecord").IsPresent = False) And (mventry("employeeStatusContractorRecord").IsPresent = False) Then
                    'employeeStatus = "Active"

                    'End If



                    Dim ADS_UF_NORMAL_ACCOUNT As Long = &H200
                    Dim ADS_UF_ACCOUNTDISABLE As Long = &H2
                    Dim ADS_UF_PASSWD_NOTREQD As Long = &H20

                    Dim currentValue As Long = csentry("userAccountControl").IntegerValue

                    Select Case (employeeStatus)
                        Case "Active"
                            csentry("userAccountControl").IntegerValue = (currentValue Or ADS_UF_NORMAL_ACCOUNT) _
                                                                            And (Not ADS_UF_ACCOUNTDISABLE)
                        Case "Terminated"
                            'csentry("userAccountControl").IntegerValue = currentValue _
                            '                                        Or ADS_UF_ACCOUNTDISABLE _
                            '   Or ADS_UF_PASSWD_NOTREQD
                            csentry("userAccountControl").IntegerValue = currentValue _
                                                                      Or ADS_UF_ACCOUNTDISABLE

                    End Select

                End If



                'Set the accountExpires value if the EmployeeEndDate value is set
                'The account will expire at the end on the day of expiry
            Case "cd.user:accountExpires<-mv.person:accountName,employeeEndDate"
                If mventry("employeeEndDate").IsPresent Then
                    Dim tempDate As Date
                    tempDate = Convert.ToDateTime(mventry("employeeEndDate").Value)
                    'Add a day so that the account expires only expires at the EOD.
                    tempDate = tempDate.AddDays(1)
                    csentry("accountExpires").Value = tempDate.ToFileTimeUtc().ToString()
                Else
                    'Set the accountExpires to never expire
                    csentry("accountExpires").Value = "9223372036854775807"
                End If





            Case Else
                ' TODO: remove the following statement and add your default script here
                Throw New EntryPointNotImplementedException()



        End Select




    End Sub

    Public Function Deprovision(ByVal csentry As CSEntry) As DeprovisionAction Implements IMASynchronization.Deprovision
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function
End Class
