Imports Microsoft.MetadirectoryServices

Public Class MAExtensionObject
    Implements IMASynchronization

    Public Sub Initialize() Implements IMASynchronization.Initialize
        ' TODO: Add initialization code here
    End Sub

    Public Sub Terminate() Implements IMASynchronization.Terminate
        ' TODO: Add termination code here
    End Sub

    Public Function ShouldProjectToMV(ByVal csentry As CSEntry, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ShouldProjectToMV
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function

    Public Function FilterForDisconnection(ByVal csentry As CSEntry) As Boolean Implements IMASynchronization.FilterForDisconnection
        ' TODO: Add connector filter code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForJoin(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByRef values As ValueCollection) Implements IMASynchronization.MapAttributesForJoin
        ' TODO: Add join mapping code here
        Throw New EntryPointNotImplementedException()
    End Sub

    Public Function ResolveJoinSearch(ByVal joinCriteriaName As String, ByVal csentry As CSEntry, ByVal rgmventry() As MVEntry, ByRef imventry As Integer, ByRef MVObjectType As String) As Boolean Implements IMASynchronization.ResolveJoinSearch
        ' TODO: Add join resolution code here
        Throw New EntryPointNotImplementedException()
    End Function

    Public Sub MapAttributesForImport(ByVal FlowRuleName As String, ByVal csentry As CSEntry, ByVal mventry As MVEntry) Implements IMASynchronization.MapAttributesForImport

        'Set the Format for the Date/Time attributes.
        'Dim FormatStringA As String = "yyyy/MM/dd"
        Dim FormatStringB As String = "yyyy-MM-ddT00:00:00.000"

        Select Case FlowRuleName


            'Convert Employee Number from number type to a string type
            Case "cd.person:EmployeeNumber->mv.person:employeeNumber"
                If csentry("EmployeeNumber").IsPresent Then
                    mventry("employeeNumber").Value = Convert.ToString(csentry("EmployeeNumber").Value)
                End If

                'If the surname is present then trim the spaces
            Case "cd.person:LastName->mv.person:sn"
                If csentry("LastName").IsPresent Then
                    mventry("sn").Value = Trim(csentry("LastName").Value)
                End If


                'If the nickname is present then trim the spaces
            Case "cd.person:Nickname->mv.person:nickName"
                If csentry("Nickname").IsPresent Then
                    mventry("nickName").Value = Trim(csentry("Nickname").Value)
                End If


                'Build the Displayname from the nickName and Surname values and add - Business Connexion to the end.
            Case "cd.person:LastName,Nickname->mv.person:displayName"
                If csentry("LastName").IsPresent And csentry("Nickname").IsPresent Then
                    Dim sn As String = Trim(csentry("LastName").Value)
                    Dim Nickname As String = Trim(csentry("Nickname").Value)
                    mventry("displayName").Value = Nickname + " " + sn + " - " + "Business Connexion"
                End If


                'Test to see if there need to be a workflow kicked off to provision a new user
                'First test and see if all the attributes are availible
            Case "cd.person:<dn>->mv.person:ProvisionRequestAD"
                If (mventry("objectSid").IsPresent = False) And (mventry("ProvisionRequestAD").IsPresent = False) And mventry("employeeStatus").IsPresent And mventry("nickName").IsPresent And mventry("sn").IsPresent And mventry("displayName").IsPresent Then
                    If mventry("employeeStatus").Value = "Active" Then
                        mventry("ProvisionRequestAD").Value = "Not Approved"
                    End If
                End If



                'Get they EmplStatus from SAP and Populate MV Value. This is for the Staff Records
            Case "cd.person:EmplStatus->mv.person:employeeStatusStaffRecord"
                If csentry("EmplStatus").IsPresent Then
                    Select Case csentry("EmplStatus").Value
                        Case "True"
                            mventry("employeeStatusStaffRecord").Value = "Active"
                        Case "False"
                            mventry("employeeStatusStaffRecord").Value = "Terminated"
                    End Select
                Else
                    mventry("employeeStatusStaffRecord").Value = "Terminated"
                End If

                'Get they EmplStatus from SAP and Populate MV Value. This is for the Contractors Records
            Case "cd.person:EmplStatus->mv.person:employeeStatusContractorRecord"
                If csentry("EmplStatus").IsPresent Then
                    Select Case csentry("EmplStatus").Value
                        Case "True"
                            mventry("employeeStatusContractorRecord").Value = "Active"
                        Case "False"
                            mventry("employeeStatusContractorRecord").Value = "Terminated"
                    End Select
                Else
                    mventry("employeeStatusContractorRecord").Value = "Terminated"
                End If


                'Set the EmployeeStatus from the Staff and Contractor Employee Status calulated above.
            Case "cd.person:EmplStatus->mv.person:employeeStatus"
                Dim StaffRecord As String = Nothing
                Dim ContractorRecord As String = Nothing
                If mventry("employeeStatusStaffRecord").IsPresent Then
                    StaffRecord = mventry("employeeStatusStaffRecord").Value
                Else
                    StaffRecord = "Terminated"
                End If
                If mventry("employeeStatusContractorRecord").IsPresent Then
                    ContractorRecord = mventry("employeeStatusContractorRecord").Value
                Else
                    ContractorRecord = "Terminated"
                End If

                If StaffRecord = "Terminated" And ContractorRecord = "Terminated" Then
                    mventry("employeeStatus").Value = "Terminated"
                ElseIf StaffRecord = "Active" Or ContractorRecord = "Active" Then
                    mventry("employeeStatus").Value = "Active"
                End If





                'Format the EmployeeStartDate in the MV to "yyyy/MM/ddTHH:mm:ss.000". Set the time value to 00H00.
            Case "cd.person:EmployeeStartDate->mv.person:employeeStartDate"
                If csentry("EmployeeStartDate").IsPresent Then 'Check if End_Date is set 
                    Dim CSDate As String
                    CSDate = csentry("EmployeeStartDate").Value 'Read the date from the CS
                    If IsDate(CSDate) Then 'Check date is a valid date and not just a blank value
                        Dim ParsedDate As DateTime = DateTime.Parse(CSDate) 'This interprets the string as a date
                        Dim NewlyFormattedDate As String = ParsedDate.ToString(FormatStringB) 'This formats the date into the desired format
                        mventry("EmployeeStartDate").Value = NewlyFormattedDate 'This puts the newly formatted date into the MV
                    Else
                        mventry("EmployeeStartDate").Delete() 'Not a valid date, or an Empty String, lets clear the attribute in the Metaverse
                    End If
                Else
                    mventry("EmployeeStartDate").Delete() 'No Date present, lets clear the attribute in the Metaverse
                End If




            Case "cd.person:EmployeeEndDate->mv.person:employeeEndDate"
                'Format the EmployeeEndDate in the MV to "yyyy/MM/ddTHH:mm:ss.000".
                If csentry("EmployeeEndDate").IsPresent Then 'Check if EmployeeEndDate  is set
                    'End date of "9999-12-31 00:00:00" is the default value for no end date
                    If csentry("EmployeeEndDate").Value = "9999-12-31 00:00:00" Then
                        mventry("employeeEndDate").Delete()
                    Else
                        Dim CSDate As String
                        CSDate = csentry("EmployeeEndDate").Value 'Read the date from the CS
                        If IsDate(CSDate) Then 'Check date is a valid date and not just a blank value
                            Dim ParsedDate As DateTime = DateTime.Parse(CSDate) 'This interprets the string as a date
                            Dim NewlyFormattedDate As String = ParsedDate.ToString(FormatStringB) 'This formats the date into the desired format
                            mventry("employeeEndDate").Value = NewlyFormattedDate 'This puts the newly formatted date into the MV
                        Else
                            mventry("employeeEndDate").Delete() 'Not a valid date, or an Empty String, lets clear the attribute in the Metaverse
                        End If
                    End If

                Else
                    mventry("employeeEndDate").Delete() 'No TerminationDate present, lets clear the attribute in the Metaverse
                End If



            Case Else
                ' TODO: remove the following statement and add your default script here
                Throw New EntryPointNotImplementedException()

        End Select
    End Sub

    Public Sub MapAttributesForExport(ByVal FlowRuleName As String, ByVal mventry As MVEntry, ByVal csentry As CSEntry) Implements IMASynchronization.MapAttributesForExport
        ' TODO: Add export attribute flow code here
        Throw New EntryPointNotImplementedException()
    End Sub

    Public Function Deprovision(ByVal csentry As CSEntry) As DeprovisionAction Implements IMASynchronization.Deprovision
        ' TODO: Remove this throw statement if you implement this method
        Throw New EntryPointNotImplementedException()
    End Function
End Class
